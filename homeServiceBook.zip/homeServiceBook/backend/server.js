const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();

const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Set up SQLite database
const db = new sqlite3.Database('./users.db', (err) => {
  if (err) {
    console.error('Error opening database:', err.message);
  } else {
    console.log('Connected to the SQLite database');
  }
});

// Create the users table if it doesn't exist
db.run(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    phone TEXT NOT NULL,
    address TEXT NOT NULL
  );
`);

// ✅ Registration route
app.post('/register', (req, res) => {
  const { name, email, password, confirmPassword, phone, address } = req.body;
    console.log(password)
  if (!name || !email || !password || !confirmPassword || !phone || !address) {
    return res.status(400).json({ error: "All fields are required." });
  }

  if (password !== confirmPassword) {
    return res.status(400).json({ error: "Passwords do not match." });
  }

  db.get('SELECT * FROM users WHERE email = ?', [email], (err, row) => {
    if (err) {
      console.error('Database error:', err.message);
      return res.status(500).json({ error: "Error checking email." });
    }

    if (row) {
      return res.status(400).json({ error: "Email already exists." });
    }

    const sql = 'INSERT INTO users (name, email, password, phone, address) VALUES (?, ?, ?, ?, ?)';
    db.run(sql, [name, email, password, phone, address], function (err) {
      if (err) {
        console.error('Database error:', err.message);
        return res.status(500).json({ error: "Error saving user to database." });
      }

      res.status(201).json({ message: "Registration successful!" });
    });
  });
});

// ✅ Login route
app.post('/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: "Email and password are required." });
  }

  db.get('SELECT * FROM users WHERE email = ?', [email], (err, row) => {
    if (err) {
      console.error('Database error:', err.message);
      return res.status(500).json({ error: "Error checking email." });
    }

    if (!row) {
      return res.status(400).json({ error: "Invalid email or password." });
    }

    if (row.password !== password) {
      return res.status(400).json({ error: "Invalid email or password." });
    }

    res.status(200).json({ message: "Login successful!" });
  });
});

// ✅ Start the server
const port = process.env.PORT || 5000;
app.listen(port, () => {
  console.log("Server running on port "+{port});
});